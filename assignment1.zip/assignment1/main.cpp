#include <iostream>
#include <fstream>
#include <algorithm>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

using namespace std;


void remove_white_space()
{
    string line;
    ifstream myfile;
    ofstream myofile;
    myfile.open ("cdtest.txt");
    myofile.open("rwstest.txt");

    while ( getline(myfile,line) )
    {
       line.erase(remove(line.begin(), line.end(), ' '), line.end());
       myofile<<line<<endl;
    }
    myofile.close();
    myfile.close();

}

void comment_delete(){
 string source;
  ifstream readFile;
  ofstream outfile;
  readFile.open("test.txt");
   getline(readFile, source, '\0');
    while(source.find("/*") != std::string::npos) {
        size_t Beg = source.find("/*");
        source.erase(Beg, (source.find("*/", Beg) - Beg)+2);
    }
    while(source.find("//") != std::string::npos) {
        size_t Beg = source.find("//");
        source.erase(Beg, source.find("\n", Beg) - Beg);
    }
    readFile.close();
    outfile.open("cdtest.txt");
    outfile<<source;
    outfile.close();
}

bool iskeyword(char buffer[]){
    char keywordlist[32][10]={"auto","break","case","char","const","continue","default",
							"do","double","else","enum","extern","float","for","goto",
							"if","int","long","register","return","short","signed",
							"sizeof","static","struct","switch","typedef","union",
							"unsigned","void","volatile","while"};

       for(int i = 0; i < 32; ++i){
		if(strcmp(keywordlist[i], buffer) == 0){
			return true;
		}
	}
        return false;
}

bool isoperator(char key){

   char operators[6] = {'+','-','*','/','%','='};
   for(int i = 0; i < 6; ++i){
                if(key == operators[i])
                   return true;
            }
   return false;
}

void recognize(){

    ifstream fin;
    ofstream fout;
    char ch, buffer[15];
    int j=0;


    fin.open("cdtest.txt");
    fout.open("rtest.txt");
    while(!fin.eof()){
            ch = fin.get();
                if(isoperator(ch))
                { fout<<ch<<"\t| operator\n";

                    }

            if(isalnum(ch)){
                buffer[j++] = ch;
            }

            else if((ch == ' ' || ch == '\n') && (j != 0)){
                    buffer[j] = '\0';
                    j = 0;

                    if(iskeyword(buffer) == 1)
                        fout<<buffer<<"\t|  keyword\n";
                    else
                        fout<<buffer<<"\t| indentifier\n";
            }

        }
    fin.close();
    fout.close();
}



void show(){

    string line;
    ifstream myfile;

    cout<<"//---------------------------Simple text---------------------------// \n\n\n";
    myfile.open ("test.txt");
    while(!myfile.eof()){
    getline(myfile,line);
        cout<<line<<endl;
    }
    myfile.close();

    cout<<"\n\n//---------------------------comment delete text---------------------------// \n\n\n";
    myfile.open ("cdtest.txt");
    while(!myfile.eof()){
    getline(myfile,line);
        cout<<line<<endl;
    }
    myfile.close();

    cout<<"\n\n//---------------------------white space remove text---------------------------// \n\n\n";
    myfile.open ("rwstest.txt");
    while(!myfile.eof()){
    getline(myfile,line);
        cout<<line<<endl;
    }
    myfile.close();

    cout<<"\n\n//---------------------------recognize text---------------------------// \n\n\n";
    myfile.open ("rtest.txt");
    while(!myfile.eof()){
    getline(myfile,line);
        cout<<line<<endl;
    }
    myfile.close();

}




int main()
{

    comment_delete();
    remove_white_space();
    recognize();
    show();

  return 0;
}
